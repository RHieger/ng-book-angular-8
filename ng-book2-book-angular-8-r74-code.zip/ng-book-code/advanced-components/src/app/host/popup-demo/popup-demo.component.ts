import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popup-demo',
  templateUrl: './popup-demo.component.html'
})
export class PopupDemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
